import snake
from threading import Thread
t = Thread(target=snake.main)
t.start()
